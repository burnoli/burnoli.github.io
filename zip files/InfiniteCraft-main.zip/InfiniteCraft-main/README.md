# Infinite Craft
This has been updated (10/29/24)
All credits go to Neal.fun
> able to be hosted on github, i think
