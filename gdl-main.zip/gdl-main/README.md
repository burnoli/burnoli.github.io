# gdl
Geometry Dash Lite ripped straight off of geometrydashlite.io
