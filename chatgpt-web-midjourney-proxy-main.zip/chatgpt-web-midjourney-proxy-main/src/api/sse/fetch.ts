/// <reference lib="dom" />

const fetch = globalThis.fetch

export { fetch }
