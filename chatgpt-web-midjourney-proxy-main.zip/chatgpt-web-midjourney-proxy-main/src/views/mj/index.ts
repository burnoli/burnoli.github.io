import aiSider from "./aiSider.vue"
import aiGpts from "./aiGpts.vue"
import aiGallery from "./aiGallery.vue"
import aiFooter from "./aiFooter.vue"

export {aiSider,aiGpts,aiGallery,aiFooter }