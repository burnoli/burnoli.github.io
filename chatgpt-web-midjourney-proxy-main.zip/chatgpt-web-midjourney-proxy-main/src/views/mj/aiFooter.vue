<script setup lang="ts">
import aiGpts from "./aiGpts.vue"
import aiGallery from "./aiGallery.vue" 
</script>
<template>
<aiGpts/>
<aiGallery/>
</template>