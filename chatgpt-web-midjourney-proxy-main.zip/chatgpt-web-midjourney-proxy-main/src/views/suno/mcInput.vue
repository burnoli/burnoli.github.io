<script setup lang="ts">
</script>
<template>
food
</template>