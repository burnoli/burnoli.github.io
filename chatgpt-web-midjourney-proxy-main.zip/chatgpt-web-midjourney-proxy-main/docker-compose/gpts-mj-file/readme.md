### docker-compose 部署教程 

```shell
    git clone https://github.com/Dooy/chatgpt-web-midjourney-proxy.git
    cd chatgpt-web-midjourney-proxy/docker-compose/gpts-mj-file
    #修改 docker-compose.yml 文件配置问文件
    
    #如果执行有问题 请执行 start_h.sh
    start.sh 
  ``` 