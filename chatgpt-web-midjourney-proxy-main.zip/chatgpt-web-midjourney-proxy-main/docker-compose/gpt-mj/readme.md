### 仅部署chatgpt和mj

```shell
    git clone https://github.com/Dooy/chatgpt-web-midjourney-proxy.git
    cd chatgpt-web-midjourney-proxy/docker-compose/gpt-mj
    #修改 docker-compose.yml 文件配置文件 

    ./deploy.sh 
  ``` 

