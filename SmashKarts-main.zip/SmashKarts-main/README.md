# SmashKarts

This is a copy of SmashKarts, It is outdated and will most likely not work.
I'll update to the latest version in a few days.
