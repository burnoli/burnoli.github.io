var e=document.createElement('div');
e.id='nbAIVXTtpUxM';
e.style.display='none';
document.body.appendChild(e);
